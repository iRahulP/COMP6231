Your task in this assignment is to look at the code and try to understand its context.

Then, you need to complete the missing code (i.e., where TODOs comments are added).

Note that the code is associated with test cases that your code need to pass them to make sure it is correct and compelte.

--
Good luck!